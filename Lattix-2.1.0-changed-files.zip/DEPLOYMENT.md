# Deploying Lattix

This guide gets Lattix running on the public internet, reachable from anywhere,
over HTTPS.

---

## Read this first — two things that shape every option

**1. HTTPS is mandatory.** Lattix does all its cryptography in the browser using
the Web Crypto API (`crypto.subtle`), which browsers only expose in a **secure
context**. Served over plain `http://` (anything other than `localhost`) the app
will fail to generate keys or log in. Every option below terminates TLS so the
app is reached over `https://` — and because the client picks `wss://`
automatically on HTTPS pages, real-time delivery works with no extra config.

**2. Run a single instance.** Login tokens, live WebSocket connections, and the
rate limiter are held **in memory** in one process. That keeps the relay simple
and dependency-free, but it means you must run **exactly one instance** — do not
enable horizontal autoscaling. A second replica wouldn't share sessions and
couldn't deliver real-time messages to users connected to the other replica.
One small instance comfortably serves a family or a team; to scale out later you
would move sessions/pub-sub into Redis.

Because everything (including uploaded file blobs) lives in a single **SQLite**
file, "persistence" just means **one durable volume** mounted at `/data`.

---

## Environment variables

| Variable | Default | Purpose |
|----------|---------|---------|
| `PORT` | `8000` | Port to listen on. Most platforms inject this; the container honors it. |
| `LATTIX_DB` | `<app>/data/lattix.db` | SQLite path. **Point this at your mounted volume**, e.g. `/data/lattix.db`. |
| `LATTIX_MAX_FILE_MB` | `50` | Max encrypted file upload size. |
| `LATTIX_FORWARDED_ALLOW_IPS` | `127.0.0.1` | Which upstream IPs may set `X-Forwarded-For`. Set to `*` **only** when the app is reachable solely through a trusted proxy (see the security note). Needed for correct per-IP rate limiting behind a proxy. |
| `LATTIX_KEEPALIVE` | `75` | Idle keep-alive seconds. Keep it above your proxy's upstream keep-alive (60 s in the shipped configs) to avoid sporadic 502s. |
| `LATTIX_CORS_ORIGINS` | *(none)* | Extra comma-separated origins allowed cross-origin (or `*`). Only needed if you host the web client on another origin. |
| `LATTIX_CORS_ALLOW_LOCAL` | `1` | Lets the desktop apps (`http://localhost:*`) and the Chrome extension use this relay remotely. `0` to turn off. |
| `LATTIX_DOCS_URL` | `/api/docs` | Set to empty to disable the interactive API docs in production. |

---

## Option A0 — Debian VPS (OVHcloud etc.) without Docker

One command sets up the relay as a hardened systemd service behind **Caddy**
(or **nginx + certbot**) with Let's Encrypt, and a firewall:

```bash
git clone https://github.com/aingram702/Lattix.git && cd Lattix
sudo bash deploy/vps/install-debian.sh --domain chat.example.com --email you@example.com --source "$PWD"
# add  --proxy nginx  to use nginx instead of Caddy
```

Full walkthrough, the reasoning behind each proxy setting, backups and
troubleshooting: [`deploy/vps/README.md`](deploy/vps/README.md).

---

## Option A — Your own server with Docker + automatic HTTPS (recommended)

The most robust, fully-owned setup. A single VPS runs the relay plus
[Caddy](https://caddyserver.com/), which fetches and renews a Let's Encrypt
certificate automatically. Files: [`deploy/docker-compose.yml`](deploy/docker-compose.yml)
and [`deploy/Caddyfile`](deploy/Caddyfile).

**You need:** a small Linux VPS (1 GB RAM is plenty — DigitalOcean, Hetzner,
Linode, Vultr, AWS Lightsail…) and a domain name.

**1. Point DNS at the server.** Create an `A` record (and `AAAA` if you have
IPv6) for e.g. `chat.example.com` → your server's public IP. Wait for it to
resolve (`dig +short chat.example.com`).

**2. Open the firewall** for ports **80** and **443** (needed for the
certificate challenge and traffic). If using `ufw`:
```bash
sudo ufw allow 80,443/tcp && sudo ufw reload
```

**3. Install Docker** (includes Compose v2):
```bash
curl -fsSL https://get.docker.com | sh
```

**4. Get the code and configure your domain:**
```bash
git clone https://github.com/aingram702/Lattix.git
cd Lattix/Lattix/deploy
echo "LATTIX_DOMAIN=chat.example.com" > .env
```

**5. Launch:**
```bash
docker compose up -d --build
```
Caddy will obtain the certificate within a few seconds. Watch progress with
`docker compose logs -f caddy`.

**6. Verify:** open `https://chat.example.com`. You should get the padlock and
the Lattix welcome screen. Check health: `curl https://chat.example.com/api/health`.

That's it — the relay is reachable worldwide over HTTPS/WSS. The app container
is **not** published to the host (only Caddy is), so trusting forwarded client
IPs is safe.

**Update later:**
```bash
cd Lattix && git pull && cd Lattix/deploy && docker compose up -d --build
```

**Back up** (the whole app is in one file):
```bash
docker run --rm -v deploy_lattix-data:/data -v "$PWD":/backup alpine \
  cp /data/lattix.db /backup/lattix-backup-$(date +%F).db
```

---

### Using the prebuilt image (optional)

The [`docker-image`](../.github/workflows/docker-image.yml) workflow publishes a
ready-to-run image to `ghcr.io/<owner>/lattix`. To use it instead of building
from source, replace the `lattix` service's `build:` block in
`docker-compose.yml` with `image: ghcr.io/<owner>/lattix:latest`.

---

## Option B — Render (managed, no server to run)

Uses [`deploy/render.yaml`](deploy/render.yaml). Render terminates TLS, gives you
an `https://…onrender.com` domain (or a custom domain), supports WebSockets, and
injects `$PORT`.

1. Copy `deploy/render.yaml` to your **repository root** and push it (Render
   reads the blueprint from the root; this repo keeps the app under `Lattix/`,
   which the blueprint's `rootDir` handles).
2. In Render: **New + → Blueprint**, select your repo, apply.
3. A persistent disk (mounted at `/data`, matching `LATTIX_DB`) requires a
   **paid instance type** — the free tier has an ephemeral filesystem and will
   lose all accounts/messages on every deploy or restart. Keep instance count at
   **1**.
4. Visit the service URL. Add a custom domain under the service's *Settings* if
   you like.

---

## Option C — Fly.io (managed, global edge)

Uses [`deploy/fly.toml`](deploy/fly.toml). Fly gives HTTPS + WebSockets and a
`.fly.dev` domain.

```bash
# from the Lattix/ app directory
cp deploy/fly.toml ./fly.toml           # then edit `app` to a unique name
fly launch --no-deploy                  # or: fly apps create lattix-yourname
fly volumes create lattix_data --size 1 --region iad   # persistent /data
fly deploy
```
The config keeps **one always-on machine** (`min_machines_running = 1`,
`auto_stop_machines = false`) so in-memory sessions survive; don't scale it
beyond one machine.

---

## Option D — Railway / other Docker PaaS

Any platform that builds a Dockerfile works. Railway auto-detects the
[`Dockerfile`](Dockerfile) (set the service **Root Directory** to `Lattix`), or
uses the [`Procfile`](Procfile). Then:

- Add a **persistent volume** mounted at `/data` and set `LATTIX_DB=/data/lattix.db`.
- Set `LATTIX_FORWARDED_ALLOW_IPS=*` (traffic arrives via the platform proxy).
- Keep it to **one instance**.

---

## Option E — Private relay with Tailscale (most private)

For a **trusted group** (family, a team), the safest option is not to expose the
relay to the public internet at all. Run it bound to `localhost` on any always-on
machine (even one at home — no router ports needed) and put it on a private
[Tailscale](https://tailscale.com) network. Tailscale issues a valid `*.ts.net`
HTTPS certificate and reaches it via WireGuard, so members connect from anywhere
while nobody else can.

```bash
# 1. Run the relay bound to loopback with a persistent volume
docker run -d --name lattix --restart unless-stopped \
  -p 127.0.0.1:8000:8000 -v lattix-data:/data lattix       # (docker build -t lattix . first)

# 2. Install Tailscale and join your tailnet
curl -fsSL https://tailscale.com/install.sh | sh
sudo tailscale up
#    In the admin console, enable MagicDNS and HTTPS Certificates.

# 3. Serve it over HTTPS on your tailnet
sudo tailscale serve --bg 8000
tailscale serve status        # -> https://<machine>.<tailnet>.ts.net
```

Install the Tailscale app on each person's device, add them to your tailnet, and
share that `https://…ts.net` URL (or set it as the extension's relay server). To
let people **without** Tailscale in, `sudo tailscale funnel --bg 8000` exposes it
publicly (less private). Full walkthrough — prerequisites, ACLs, backups,
troubleshooting — is on the wiki:
[Private Relay with Tailscale](https://github.com/aingram702/Lattix/wiki/Private-Relay-with-Tailscale).

---

## Connecting the desktop apps and the Chrome extension

The web app served by your relay needs no setup. The desktop apps and the
extension choose their relay in the app itself: on the sign-in screen click
**Change** next to *Relay: …* — or, once signed in, **Settings → Relay server →
Change…** — enter your HTTPS URL (e.g. `https://chat.example.com`), press
**Test connection**, then **Save & connect**. The test confirms the relay answers,
is a Lattix relay, and that WebSockets pass through your proxy.

Unlocking an existing vault on a relay that doesn't know it offers to register
the same identity there. All crypto still runs locally; only ciphertext reaches
the server.

---

## Security checklist

- ✅ **HTTPS only** — never expose the app over plain HTTP (crypto won't run, and
  the login secret would be sent in the clear).
- ✅ **Don't publish the app container directly.** In Option A only Caddy binds
  80/443; the relay is internal. Only set `LATTIX_FORWARDED_ALLOW_IPS=*` when a
  trusted proxy is the sole path to the app — otherwise a client could spoof
  `X-Forwarded-For` to dodge rate limiting.
- ✅ **Persist `/data`** and back it up — it holds every account and message.
- ✅ Optionally set `LATTIX_DOCS_URL=` to hide the API docs.
- ℹ️ The server is a zero-knowledge relay: it only ever stores ciphertext and
  public keys, so a server compromise does not reveal message contents. Users
  should still verify contact **safety codes** to defend against a malicious
  server substituting keys.

---

## Troubleshooting

| Symptom | Cause / fix |
|---------|-------------|
| "Cannot generate keys" / crypto errors | The page isn't a secure context. You must use `https://` (or `localhost`). |
| Real-time messages don't arrive, but appear after refresh | WebSocket isn't reaching the app. Ensure the proxy forwards `/ws` (Caddy does automatically) and that you're on `https://` so the client uses `wss://`. |
| Everyone shares one rate-limit bucket / gets 429s together | Proxy client IP isn't being forwarded. Set `LATTIX_FORWARDED_ALLOW_IPS=*` (behind a trusted proxy only). |
| Accounts/messages vanish after a redeploy | No persistent volume. Mount one at `/data` and set `LATTIX_DB=/data/lattix.db` (paid tier on some PaaS). |
| Test connection: *HTTPS works, but WebSocket connections aren't getting through* | The proxy isn't forwarding `Upgrade`/`Connection` for `/ws`. Use the shipped Caddy/nginx configs; with Cloudflare in front, enable WebSockets. |
| Desktop app / extension: *Couldn't reach …* but the web app works | A relay older than 2.1 doesn't allow other origins — upgrade it, or set `LATTIX_CORS_ORIGINS`. |
| Sporadic `502` behind nginx | Proxy upstream keep-alive outlives the relay's. Keep `LATTIX_KEEPALIVE` (75) above the proxy's (60). |
| Large file uploads rejected | Raise `LATTIX_MAX_FILE_MB` and, in Option A, the Caddy `max_size` in the Caddyfile. |
| Certificate won't issue (Option A) | DNS must resolve to the server and ports 80/443 must be open before `docker compose up`. Check `docker compose logs caddy`. |
